package com.bank.util;

import java.util.Scanner;

public class BankClient {
	Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("**********WELCOME TO ABC BANK***********");
		System.out.println("");
		System.out.println("          1.Account Holder              ");
		System.out.println("          2.Admin                       ");
		System.out.println("****************************************");
	}
}
