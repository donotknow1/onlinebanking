package com.bank.dtobean;

public class BankBean {
	

}
